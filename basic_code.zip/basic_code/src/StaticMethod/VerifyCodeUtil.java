package StaticMethod;
//静态方法设计工具类
public class VerifyCodeUtil {

    //不用实例方法创建，因为实例方法属于对象持有，每次调用都会创建新的对象，会占内存
    //静态方法，直接用类名调用，调用方便且占用内存少

    //工具类没有创建对象的需求，建议将工具类的构造器进行私有
    private VerifyCodeUtil(){

    }

    public static String getRandomChar(int number) {
        //验证码初始为空，通过循环，每次生成一个随机字符，并拼接在验证码中
        String code = "";
        for (int i = 0; i < number; i++) {
            //生成1到3的随机数，1代表数字，2代表大写字母，3代表小写字母
            int num = (int) (Math.random() * 3 + 1);
            switch (num) {
                case 1:
                    //生成0到9的随机数
                    //数字0的ASCII码是48，而非正常的数字0，所以要加上48
                    code += (char) (Math.random() * 10 + 48);
                    break;
                case 2:
                    //生成65到90的随机数
                    //大写字母的ASCII码是65，而非正常的大写字母A，所以要加上65
                    code += (char) (Math.random() * 26 + 65);
                    break;
                case 3:
                    //生成97到122的随机数
                    //小写字母的ASCII码是97，而非正常小写字母a，所以要加上97
                    code += (char) (Math.random() * 26 + 97);
                    break;
            }
        }
        return code;
    }
}
