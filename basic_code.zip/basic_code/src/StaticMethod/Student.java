package StaticMethod;

//静态方法中可以直接访问静态成员变量和静态方法，不可以直接访问实例成员变量和实例方法
//实例方法中既可以直接访问静态成员变量和静态方法，也可以直接访问实例成员变量和实例方法
//实例方法中可以出现this关键字，静态方法中不可以出现this关键字


public class Student {
    private double score;
    //静态方法，有static 修饰，属于类持有

    public static void printHelloWorld(){
        System.out.println("HelloWorld");
        System.out.println("HelloWorld");
    }

    //实例方法，无static修饰，属于对象持有
    public  void printScore(){
        System.out.println(score>=60 ? "及格" : "不及格");
    }

    public void setScore(double score) {
        this.score = score;
    }
}
