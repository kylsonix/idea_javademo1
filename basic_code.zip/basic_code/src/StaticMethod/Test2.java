package StaticMethod;

public class Test2 {
    public static void main(String[] args) {
        //直接调用工具类中的静态方法
        //可以减少相同代码的重复编写
        String code = VerifyCodeUtil.getRandomChar(4);
        System.out.println( code);
    }
}
