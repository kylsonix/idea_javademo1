package StaticMethod;

//如果这个方法只是做一个功能且不需要直接访问对象的数据，那么这个方法就可以直接定义为静态方法
//如果这个方法是对象的行为，需要访问对象数据，那么这个方法就必须定义成实例方法
//main 方法，是属于静态方法

public class Test {
    public static void main(String[] args) {
        //static修饰和不修饰成员方法，静态方法，实例方法的区别
        //访问静态方法，类名.静态方法名（推荐）
        Student.printHelloWorld();
        //对象名.静态方法名（不推荐）
        Student s1 = new Student();
        s1.printHelloWorld();

        //访问实例方法，不能用类名访问
        //访问实例方法，对象名.实例方法名
        s1.setScore(90);
        s1.printScore();
    }
}
