package ThisDemo;

public class Student {
    //this是一个变量，可以用在方法中，来拿到当前对象
    //哪个对象调用这个方法，this就拿到哪个对象
    //this主要用来解决：变量名称和形参名称冲突问题
    public void print()
    {
        System.out.println(this);
    }
}
