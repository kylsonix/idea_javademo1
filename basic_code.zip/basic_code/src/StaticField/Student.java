package StaticField;

public class Student {
    //static ,静态变量修饰，属于类，只加载一次，可以被所有对象所访问
    //如学生的老师，学校，默认下属于静态变量
    //而学生的学号，姓名，年龄，属于实例变量
    //同一个类中，访问静态变量，类名.静态变量名中，类名可不写
    String name;
    int age;
    static String school;
    static String teacher;
}
