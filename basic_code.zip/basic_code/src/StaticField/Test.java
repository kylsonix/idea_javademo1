package StaticField;

public class Test {
    //静态变量可以用类名访问如：Student.school
    public static void main(String[] args) {
        //推荐静态变量用类名访问
        Student.school = "学校11";
        System.out.println(Student.school);
        //静态变量也可以用对象名访问，但不推荐
        Student s1 = new Student();
        s1.school = "学校22";
        Student s2 = new Student();
        s2.school = "学校33";
        System.out.println(s2.school);
        //由于静态变量school是类变量，对象之间共享，所以s1.school和s2.school的值相同
        System.out.println(s1.school);//输出：学校33

        //不能用类名去访问实例变量，会报错
        //System.out.println(Student.name);

    }
}
